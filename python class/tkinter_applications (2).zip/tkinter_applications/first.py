import tkinter

root = tkinter.Tk()
# Tk() is used to create root window


root.mainloop()
# to hold our application untill we close it