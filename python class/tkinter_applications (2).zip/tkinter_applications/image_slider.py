import tkinter as tk
import os
from PIL.ImageTk import PhotoImage

images = [  ]
for file1, file2 in zip(os.listdir('imgs'), os.listdir('text')):
    path1 = os.path.join('imgs', file1)
    path2 = os.path.join('text', file2)
    images.append((path1, path2))

root = tk.Tk()

i = 0
image = PhotoImage(file=images[i][0])
with open(images[i][1], encoding='utf-8') as file:
    text = file.read()
    file.close()
w = tk.Label(root, compound=tk.RIGHT,fg='white', bg='black', font=('monospace', 20, 'bold', 'italic'))
w.config(text=text, image=image)

w.pack(fill=tk.BOTH, expand=tk.YES)

exit_button = tk.Button(root, text="Exit",
    font=('monospace', 20, 'bold'),)
exit_button.pack(side=tk.BOTTOM, fill=tk.X, expand=tk.YES)

prev_button = tk.Button(root, text="Prev",
    font=('monospace', 20, 'bold'),)
prev_button.config(command=lambda :change_image(forward=False))
prev_button.pack(side=tk.LEFT, fill=tk.X, expand=tk.YES)

next_button = tk.Button(root, text="Next",
    font=('monospace', 20, 'bold'),)
next_button.config(command=lambda :change_image(forward=True))
next_button.pack(side=tk.LEFT, fill=tk.X, expand=tk.YES)

exit_button.config(command=lambda : root.quit())

def change_image(forward=True):
    global i, text, image
    if forward: # [1,2, 4]
        if i < len(images)-1:
            i += 1
        else:
            i = 0
    else:
        if i == 0:
            i = len(images) - 1
        else:
            i = i - 1
    image = PhotoImage(file=images[i][0])
    with open(images[i][1], encoding='utf-8') as file:
        text = file.read()
        file.close()
    w.config(text=text, image=image)
    w.text = text
    w.image = image


root.mainloop()
