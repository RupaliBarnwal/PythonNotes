from django.contrib import admin
from .models import UserAdd
# Register your models here.
admin.site.register(UserAdd)
