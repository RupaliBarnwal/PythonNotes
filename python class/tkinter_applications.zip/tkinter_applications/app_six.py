import tkinter as tk 

root = tk.Tk()

counter = 0
def change_counter():
    global counter
    counter += 1
    l1.config(text=f"{counter}")
    l1.after(1000, change_counter)

l1 = tk.Label(root, text=f"{counter}", font=25)
l1.pack(fill=tk.X, expand=tk.YES)

b = tk.Button(root, text='Stop', font=25, command=root.destroy)
b.pack(fill=tk.X, expand=tk.YES)

root.after(1000, change_counter)
root.geometry('400x400')
root.mainloop()