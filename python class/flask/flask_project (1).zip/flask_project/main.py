from flask import Flask,render_template,request,make_response,session,redirect,url_for
import pymysql as sql

app = Flask(__name__)
app.secret_key = "pijpieijpipe123456pofjpofjpoejpojjbvuhoijpjlejpo"

@app.route("/")
def index():
    if request.cookies.get("islogin"):
        return render_template("afterlogin.html")
    return render_template("nav.html")

@app.route("/login/")
def login():
    if request.cookies.get("islogin"):
        return render_template("afterlogin.html")
    return render_template("login.html")

@app.route("/afterlogin/",methods=["POST","GET"])
def afterlogin():
    if request.method == "GET":
        return render_template("login.html")
    elif request.method == "POST":  #{"email":email,"passwd":pass}
        email = request.form.get("email")
        password = request.form.get("passwd")
        if email:
            if password:
                try:
                    db = sql.connect(host="localhost",port=3306,user="root",password="",database="batch7_15")
                except Exception as e:
                    print(e)
                    return render_template("login.html")
                else:
                    cursor = db.cursor()
                    cmd = f"select * from user where email='{email}' and password='{password}'"
                    cursor.execute(cmd)
                    data = cursor.fetchone()
                    #print(data)
                    if data:
                        username = data[2]
                        #resp = make_response(render_template("afterlogin.html")) #make response object and give that page that you want to return if the response object will be returned 
                        #resp.set_cookie("email",email) #email = key, email = value
                        #resp.set_cookie("islogin","true") #islogin key and true value
                        #return resp 
                        session['email'] = email
                        session['islogin'] = "True"
                        return render_template("afterlogin.html",user=username)
                    else:
                        error = "Invalid email or password!!!!"
                        return render_template("login.html",error=error) 
                return f"{email},{password}"
            else:
                error = "Invalid password"
                return render_template("login.html",error=error)
        else:
            error = "Invalid email"
            return render_template("login.html",error=error)
@app.route("/signup/")
def signup():
    return render_template("signup.html")

@app.route("/aftersignup/",methods=["POST","GET"])
def aftersignup():
    if request.method == "POST":
        #print(request.form)
        email = request.form.get("email")
        password = request.form.get("passwd")
        gender = request.form.get("gender")
        username = email.split("@")[0]
        if email and password:
            try:
                db = sql.connect(host="localhost",port=3306,user="root",password="",database="batch7_15")
            except Exception as e:
                print(e)
                return render_template("signup.html")
            else:
                cursor = db.cursor()
                cmd = f"select * from user where email='{email}'"
                cursor.execute(cmd)
                data = cursor.fetchone()
                if data:
                    error = "Email Already Registered!!!"
                    return render_template("signup.html",error=error)
                else:
                    if len(password)>=8:
                            s = 0
                            l = 0
                            u = 0
                            n = 0
                        #for i in password:
                            for i in password:
                                special = "".join(["@","&","$","*","#","%","!"])
                                if i in special:
                                    s += 1 
                                if i.islower():
                                    l += 1
                                if i.isupper():
                                    u += 1
                                if i.isdigit():
                                    n += 1
                            if s>=1 and l>=1 and u>=1 and n>=1:
                                cmd = f"insert into user values('{email}','{password}','{username}','{gender}')"
                                cursor.execute(cmd)
                                db.commit()
                                return render_template("login.html")
                            else:
                                error = "Incorrect Password"
                                return render_template("signup.html",error=error)
                    else:
                        error = "Incorrect Password"
                        return render_template("signup.html",error=error)

            #return f"Email : {email},Password : {password},Gender : {gender}"
        else:
            error = "Invalid Email or password"
            return render_template("signup.html",error=error)
    else:
        return render_template("signup.html")

@app.route("/logout/")
def logout():
    #resp = make_response(render_template("nav.html"))
    #resp.delete_cookie("islogin")
    #resp.delete_cookie("email")
    #return resp
    del session['email']
    del session['islogin']
    return redirect(url_for("index")) #url_for(func_name)
    #redirect to the url on which index function is running
    #return render_template("nav.html")
app.run(host="localhost",port=80,debug=True)
#to have validation on password
# 1. len should be greater than 8
# 2. it should have one special character,atleast 1 upper, atleast 1 lower, atleast 1 number
# store password in encrypt form
#passlib, cryptography
#SMTP????