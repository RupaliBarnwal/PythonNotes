import tkinter as tk 

root = tk.Tk()

colors = ['red', 'green', 'yellow', 'blue', 'cyan', 'magenta', 'black' ]
index = 0
def change_color():
    global index
    if index == len(colors):
        index = 0
    label.config(bg=colors[index])
    index += 1
    label.after(1000, change_color)
label = tk.Label(root, text="Let's change Background", font=('Times', 30, 'bold'),fg='white')

label.pack(fill=tk.BOTH, expand=tk.YES)

label.after(1000, change_color)
# after mili seconds call this function

root.geometry('500x400')

root.mainloop()