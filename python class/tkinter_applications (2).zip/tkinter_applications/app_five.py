import tkinter as tk 
from random import choice
colors = [ '1', '2', '3', '4', '5', '6', '7', '8', '9',
            'A', 'B', 'C', 'D', 'E', 'F' ] 
root = tk.Tk()
def change_color():
    color = "#"+"".join([ choice(colors) for _ in range(6) ])
    label.config(bg=color)
    label.after(1000, change_color)
label = tk.Label(root, text="Let's change Background", font=('Times', 30, 'bold'),fg='white')

label.pack(fill=tk.BOTH, expand=tk.YES)

label.after(1000, change_color)
# after mili seconds call this function

root.geometry('500x400')

root.mainloop()