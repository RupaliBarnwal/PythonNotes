import tkinter as tk 
from PIL.ImageTk import PhotoImage
master = tk.Tk()
# Tk() creates a master window

main_frame = tk.Frame(master)
main_frame.config(bg='#aaaaaa',)

image  = PhotoImage(file='images/test2.jpg')
height, width = int(image.height()/10), int(image.width()/10)

print(height, width)
text_label = tk.Label(main_frame, height=height, width=width)
text_label.config(font=('Monospace', 10, 'bold', 'italic'),
                  fg='white', bg='#123456', 
                  padx=30, justify='left' )
text_label.config(text="""Python is Awesome.
Life is Awesome.
Be Awesome.
Share Everything.
""")

text_label.pack(side=tk.LEFT, expand=tk.YES,  padx=5, pady=5, )

image_label = tk.Label(main_frame, image=image, )
image_label.config()
image_label.pack(side='right')



main_frame.pack(fill=tk.BOTH, expand=tk.YES,  padx=5, pady=5)

master.config(bg='#cccccc')
master.title('App One')
master.iconbitmap('images/master.ico')
#master.wm_minsize(400, 400)
#master.geometry('400x400')
# you can set max size if don't want to resize your window
master.mainloop()