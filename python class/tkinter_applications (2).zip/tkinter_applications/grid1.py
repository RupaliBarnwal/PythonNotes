import tkinter as tk 
from random import choice
from tkinter import Grid
toggle = True
root = tk.Tk() 
labels = []

def make_color():
    choices = list('1234567890ABCDEF')
    color = '#'+"".join([ choice(choices) for _ in range(6) ])
    return color
for row in range(5):
    # row -> 0, 1, 2, 3, 4
    for col in range(5):
        # row - 0, col - 0, 1, 2, 3, 4 
        text = f"row: {row}\ncol: {col}"
        label = tk.Label(root, text=text, font=("Monospace", 15, 'bold'))
        if toggle:
            label.config(fg=make_color(), bg=make_color())
            toggle = False
        else:
            label.config(bg=make_color(), fg=make_color())
            toggle = True
        labels.append(label)
        label.grid(row=row, column=col, sticky=tk.N+tk.S+tk.E+tk.W)
for row in range(5):
    weight = 1
    if row % 2 == 0:
        weight = 2
    Grid.rowconfigure(root, row, weight=weight)
    Grid.columnconfigure(root, row, weight=weight)
    root.grid_columnconfigure(row, minsize=20)
    root.grid_rowconfigure(row, minsize=20)
root.mainloop()