from django.shortcuts import render
from django.http import HttpResponse
from . import views
# Create your views here.
def index(request):
    return render(request,"nav.html")
    #it will go to the path you have defined in settings.py file and will find the page and return it
    #return HttpResponse("User app")

def home(request):
    return HttpResponse("Welcome to my user app home")
