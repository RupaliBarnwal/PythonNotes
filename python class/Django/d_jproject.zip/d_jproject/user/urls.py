from django.urls import path
from . import views

urlpatterns = [
    path("",views.index), #"" --> localhost/user, domain/user
    path("home/",views.home), # localhost/user/home --> home function
]