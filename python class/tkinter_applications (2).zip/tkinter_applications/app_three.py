import tkinter as tk
from PIL.ImageTk import PhotoImage
root = tk.Tk()

image = PhotoImage(file='images/test2.jpg')

text = """Python is Awesome.
Life is Awesome.
Be Awesome.
Share Everything.
This is Cool Right.
"""

w = tk.Label(root, compound=tk.RIGHT,fg='white', bg='black', font=('monospace', 20, 'bold', 'italic'))
w.config(text=text, image=image)
w.pack(fill=tk.BOTH, expand=tk.YES)

toggle = False
def change_color():
    global toggle
    if toggle:
        w.config(fg='white', bg='black')
        toggle=False
    else:
        w.config(fg='black', bg='white')
        toggle=True
change_button = tk.Button(root)
change_button.config(text='Change Color', fg='white', bg='#123456', font=('monospace', 20, 'bold', 'italic'))
change_button.config(command= lambda: change_color())
change_button.pack(fill=tk.X)

exit_button = tk.Button(root)
exit_button.config(text='Exit', bg='white', fg='#123456', font=('monospace', 20, 'bold', 'italic'))
exit_button.config(command= lambda: root.quit(), height=2)
exit_button.pack(fill=tk.X, expand=tk.YES)

b = tk.Button(root, text='A button', font=10, width=20, height=2)
b.config(justify='left')
b.pack(side=tk.LEFT)

b1 = tk.Button(root, text='A button', font=10, width=20, height=2)
b1.config(justify='left')
b1.pack(side=tk.LEFT)

b2 = tk.Button(root, text='A button', font=10, width=20, height=2)
b2.config(justify='left')
b2.pack(side=tk.LEFT)

root.mainloop()