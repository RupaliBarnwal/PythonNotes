import tkinter as tk 
toggle = True
root = tk.Tk() 
labels = []

for row in range(5):
    # row -> 0, 1, 2, 3, 4
    for col in range(5):
        # row - 0, col - 0, 1, 2, 3, 4 
        text = f"row: {row}\ncol: {col}"
        label = tk.Label(root, text=text, font=("Monospace", 15, 'bold'))
        if toggle:
            label.config(fg='#eeeeee', bg="#333333")
            toggle = False
        else:
            label.config(bg='#eeeeee', fg="#333333")
            toggle = True
        labels.append(label)
        label.grid(row=row, column=col)
root.mainloop()