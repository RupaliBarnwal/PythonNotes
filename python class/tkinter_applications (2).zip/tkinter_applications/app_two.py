import tkinter as tk
from PIL.ImageTk import PhotoImage
root = tk.Tk()

image = PhotoImage(file='images/test2.jpg')

text = """Python is Awesome.
Life is Awesome.
Be Awesome.
Share Everything.
This is Cool Right.
"""

w = tk.Label(root, compound=tk.RIGHT,fg='white', bg='black', font=('monospace', 20, 'bold', 'italic'))
w.config(text=text, image=image)

w.pack(fill=tk.BOTH, expand=tk.YES)
#root.mainloop()
image1 = PhotoImage(file='images/test2.jpg')

text = """Python is Awesome.
Life is Awesome.
Be Awesome.
Share Everything.
This is Cool Right.
"""

x = tk.Label(root, compound=tk.RIGHT,fg='white', bg='black', font=('monospace', 20, 'bold', 'italic'))
x.config(text=text, image=image1)

x.pack(fill=tk.BOTH, expand=tk.YES)
root.mainloop()