import tkinter as tk 
from random import choice 
from tkinter import simpledialog

last_fg = None 
last_bg = None
def make_color():
    global last_fg, last_bg
    choices = list('1234567890ABCDEF')
    while True:
        fg = '#'+"".join([ choice(choices) for _ in range(6) ])
        if fg == last_fg:
            continue
        else:
            bg =  '#'+"".join([ choice(choices) for _ in range(6) ])
            if bg == last_bg or fg == bg:
                continue
        last_fg, last_bg = fg, bg
        return fg, bg
def change_color(widget):
    fg, bg = make_color()
    widget.config( bg=bg)

def do_after(widget):
    global time_left
    if time_left:
        time_left -= 1
        widget.config(text=f"Time Left: {str(time_left).zfill(3)}")
        change_color(widget)
        widget.after(1000, lambda: do_after(widget))
    else:
        widget.config(text="!!!!Time UP!!!!", fg='red', bg='#cccccc')

def restart(widget):
    global time_left
    time_left = initial_time
    widget.after(1000, lambda : do_after(widget))



root = tk.Tk()
#root.withdraw()
initial_time = simpledialog.askinteger(title="Break Time", prompt="Enter Break Time: ",)
time_left =initial_time

label = tk.Label(root, text=f"Time Left: {str(time_left).zfill(3)}")
label.config(font=("Monospace", 40, 'bold', 'italic'),fg='white',
    height=5, )

label.pack(fill=tk.X, expand=tk.YES)

restart_button = tk.Button(root, text="!!Restart!!")
restart_button.config(font=("Monospace", 20, 'bold', 'italic'))
restart_button.config(fg='white', bg='#123456', command=lambda : restart(label))
restart_button.pack(fill=tk.X, expand=tk.YES)

exit_button = tk.Button(root, text="!!EXIT!!")
exit_button.config(font=("Monospace", 20, 'bold', 'italic'))
exit_button.config(bg='white', fg='#123456', command = lambda: root.destroy())
exit_button.pack(fill=tk.X, expand=tk.YES)



label.after(1000, lambda :do_after(label))

root.geometry('400x400')
root.mainloop()