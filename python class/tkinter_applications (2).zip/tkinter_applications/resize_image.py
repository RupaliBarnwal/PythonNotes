from PIL import Image 
import os 

for file in os.listdir('test_image'):
    path = os.path.join('test_image', file)
    im = Image.open(path)
    im.thumbnail((300,300))
    im.save(os.path.join('imgs', file))