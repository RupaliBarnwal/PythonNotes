from flask import Flask,render_template,request
import pymysql as sql

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("nav.html")

@app.route("/login/")
def login():
    return render_template("login.html")

@app.route("/afterlogin/",methods=["POST","GET"])
def afterlogin():
    if request.method == "GET":
        return render_template("login.html")
    elif request.method == "POST":  #{"email":email,"passwd":pass}
        email = request.form.get("email")
        password = request.form.get("passwd")
        if email:
            if password:
                try:
                    db = sql.connect(host="localhost",port=3306,user="root",password="",database="batch7_15")
                except Exception as e:
                    print(e)
                    return render_template("login.html")
                else:
                    cursor = db.cursor()
                    cmd = f"select * from user where email='{email}' and password='{password}'"
                    cursor.execute(cmd)
                    data = cursor.fetchone()
                    #print(data)
                    if data:
                        username = data[2]
                        return render_template("afterlogin.html",user=username)
                    else:
                        error = "Invalid email or password!!!!"
                        return render_template("login.html",error=error) 
                return f"{email},{password}"
            else:
                error = "Invalid password"
                return render_template("login.html",error=error)
        else:
            error = "Invalid email"
            return render_template("login.html",error=error)
@app.route("/signup/")
def signup():
    return render_template("signup.html")

@app.route("/aftersignup/",methods=["POST","GET"])
def aftersignup():
    if request.method == "POST":
        #print(request.form)
        email = request.form.get("email")
        password = request.form.get("passwd")
        gender = request.form.get("gender")
        username = email.split("@")[0]
        if email and password:
            try:
                db = sql.connect(host="localhost",port=3306,user="root",password="",database="batch7_15")
            except Exception as e:
                print(e)
                return render_template("signup.html")
            else:
                cursor = db.cursor()
                cmd = f"select * from user where email='{email}'"
                cursor.execute(cmd)
                data = cursor.fetchone()
                if data:
                    error = "Email Already Registered!!!"
                    return render_template("signup.html",error=error)
                else:
                    cmd = f"insert into user values('{email}','{password}','{username}','{gender}')"
                    cursor.execute(cmd)
                    db.commit()
                    return render_template("login.html")
            #return f"Email : {email},Password : {password},Gender : {gender}"
        else:
            error = "Invalid Email or password"
            return render_template("signup.html",error=error)
    else:
        return render_template("signup.html")

app.run(host="localhost",port=80,debug=True)
#to have validation on password
# 1. len should be greater than 8
# 2. it should have one special character,atleast 1 upper, atleast 1 lower, atleast 1 number
# store password in encrypt form
#passlib, cryptography
#SMTP????